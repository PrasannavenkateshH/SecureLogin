import { useEffect, useRef } from 'react';
import * as THREE from 'three';

export function ThreeAnimation() {
  const mountRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    if (!mountRef.current) return;
    
    // Set up scene
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, 1, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({ alpha: true });
    renderer.setSize(200, 200);
    renderer.setClearColor(0x000000, 0);
    
    // Add to DOM
    mountRef.current.appendChild(renderer.domElement);
    
    // Create objects
    const torusGeometry = new THREE.TorusKnotGeometry(3, 1, 100, 16);
    const material = new THREE.MeshBasicMaterial({ 
      color: 0xff6600,
      wireframe: true
    });
    const torusKnot = new THREE.Mesh(torusGeometry, material);
    scene.add(torusKnot);
    
    // Position camera
    camera.position.z = 10;
    
    // Animation loop
    const animate = () => {
      requestAnimationFrame(animate);
      
      torusKnot.rotation.x += 0.01;
      torusKnot.rotation.y += 0.01;
      
      renderer.render(scene, camera);
    };
    
    animate();
    
    // Handle resize
    const handleResize = () => {
      const size = Math.min(200, window.innerWidth / 4);
      renderer.setSize(size, size);
    };
    
    window.addEventListener('resize', handleResize);
    handleResize();
    
    // Cleanup
    return () => {
      window.removeEventListener('resize', handleResize);
      if (mountRef.current) {
        mountRef.current.removeChild(renderer.domElement);
      }
      
      // Dispose resources
      torusGeometry.dispose();
      material.dispose();
      renderer.dispose();
    };
  }, []);
  
  return <div ref={mountRef} className="absolute right-[-40px] top-[-40px] opacity-75 z-10" />;
}