import { useEffect, useState } from "react";
import { useAuth } from "../hooks/use-auth";
import { Redirect } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Loader2, Eye, EyeOff } from "lucide-react";
import rutomatrixLogoPath from '../assets/rutomatrix_logo.png';

// Form schemas
const loginSchema = z.object({
  username: z.string().min(1, "Username is required"),
  password: z.string().min(1, "Password is required"),
});

const registerSchema = z.object({
  fullName: z.string().min(2, "Full name is required"),
  email: z.string().email("Please enter a valid email address"),
  username: z.string().min(3, "Username must be at least 3 characters"),
  password: z
    .string()
    .min(8, "Password must be at least 8 characters")
    .regex(/[A-Z]/, "Password must contain at least 1 uppercase letter")
    .regex(/[a-z]/, "Password must contain at least 1 lowercase letter")
    .regex(/[0-9]/, "Password must contain at least 1 number")
    .regex(/[^A-Za-z0-9]/, "Password must contain at least 1 special character"),
  confirmPassword: z.string().min(1, "Please confirm your password"),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords do not match",
  path: ["confirmPassword"],
});

type LoginFormValues = z.infer<typeof loginSchema>;
type RegisterFormValues = z.infer<typeof registerSchema>;

export default function AuthPage() {
  const { user, loginMutation, registerMutation } = useAuth();
  const [isRegister, setIsRegister] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [particles, setParticles] = useState<any[]>([]);
  
  // Check if user is logged in
  useEffect(() => {
    console.log("Auth page - current user:", user);
  }, [user]);

  // Login form
  const loginForm = useForm<LoginFormValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: "",
      password: "",
    },
  });

  // Register form
  const registerForm = useForm<RegisterFormValues>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      fullName: "",
      email: "",
      username: "",
      password: "",
      confirmPassword: "",
    },
  });
  
  // Password strength state
  const [passwordStrength, setPasswordStrength] = useState({
    score: 0,
    lengthValid: false,
    hasUppercase: false,
    hasLowercase: false,
    hasNumber: false,
    hasSpecial: false
  });

  // Generate AI particles effect for the left panel
  useEffect(() => {
    const generateParticles = () => {
      const newParticles = [];
      const particleCount = 30;

      for (let i = 0; i < particleCount; i++) {
        // 30% chance for particle to be orange
        const isOrange = Math.random() > 0.7;
        
        newParticles.push({
          id: i,
          size: Math.random() * 15 + 5,
          posX: Math.random() * 80,
          posY: Math.random() * 100,
          opacity: Math.random() * 0.4 + 0.1,
          blur: Math.random() * 2,
          duration: Math.random() * 20 + 10,
          isOrange: isOrange
        });
      }

      setParticles(newParticles);
    };

    generateParticles();
  }, []);

  // Handle login form submission
  const onLoginSubmit = (data: LoginFormValues) => {
    loginMutation.mutate(data);
  };

  // Handle register form submission
  const onRegisterSubmit = (data: RegisterFormValues) => {
    // Remove confirmPassword as it's not needed for the API call
    const { confirmPassword, ...userData } = data;
    registerMutation.mutate(userData, {
      onSuccess: () => {
        // Reset the form
        registerForm.reset();
        // Switch back to login mode so they can sign in
        setTimeout(() => {
          setIsRegister(false);
        }, 1000);
      }
    });
  };

  // Toggle between login and register forms
  const toggleAuthMode = () => {
    setIsRegister(!isRegister);
  };

  // Check password strength
  const checkPasswordStrength = (password: string) => {
    // Check requirements
    const lengthValid = password.length >= 8;
    const hasUppercase = /[A-Z]/.test(password);
    const hasLowercase = /[a-z]/.test(password);
    const hasNumber = /[0-9]/.test(password);
    const hasSpecial = /[^A-Za-z0-9]/.test(password);
    
    // Calculate score (0-5)
    let score = 0;
    if (lengthValid) score++;
    if (hasUppercase) score++;
    if (hasLowercase) score++;
    if (hasNumber) score++;
    if (hasSpecial) score++;
    
    setPasswordStrength({
      score,
      lengthValid,
      hasUppercase,
      hasLowercase,
      hasNumber,
      hasSpecial
    });
  };

  return (
    <div className="flex w-full min-h-screen">
      {/* Background Pattern */}
      <div 
        className="fixed top-0 left-0 w-1/2 h-full bg-gradient-to-br from-secondary to-secondary/70 -z-10"
        style={{ clipPath: "polygon(0 0, 100% 0, 80% 100%, 0% 100%)" }}
      >
        {particles.map((particle) => (
          <div
            key={particle.id}
            className={`absolute rounded-full ${particle.isOrange ? 'bg-primary/20' : 'bg-white/10'}`}
            style={{
              width: `${particle.size}px`,
              height: `${particle.size}px`,
              left: `${particle.posX}%`,
              top: `${particle.posY}%`,
              opacity: particle.opacity,
              filter: `blur(${particle.blur}px)`,
              animation: `float ${particle.duration}s linear infinite`,
            }}
          />
        ))}
      </div>

      {/* Left Panel */}
      <div className="w-1/2 flex flex-col justify-center p-16 text-white relative">
        <h1 className="text-5xl font-bold mb-4 bg-gradient-to-r from-white via-primary-foreground to-primary/80 bg-clip-text text-transparent">
          Unlock the Power of Language AI
        </h1>
        <p className="text-lg text-indigo-100 max-w-[80%] mb-8">
          Access your personal AI language model dashboard. Generate, analyze, and interact with text like never before.
        </p>
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <svg className="w-5 h-5" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M11.3 1.046A1 1 0 0112 2v5h4a1 1 0 01.82 1.573l-7 10A1 1 0 018 18v-5H4a1 1 0 01-.82-1.573l7-10a1 1 0 011.12-.38z" clipRule="evenodd" />
            </svg>
            <span>Instant text generation</span>
          </div>
          <div className="flex items-center gap-2">
            <svg className="w-5 h-5" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clipRule="evenodd" />
            </svg>
            <span>Secure & private</span>
          </div>
        </div>
      </div>

      {/* Right Panel */}
      <div className="w-1/2 flex justify-center items-center p-8">
        <div className="bg-white rounded-2xl shadow-xl p-12 w-full max-w-[480px] transition-transform hover:translate-y-[-5px]">
          {/* Logo */}
          <div className="flex items-center mb-8 text-gray-900 relative">
            <img 
              src={rutomatrixLogoPath} 
              alt="Rutomatrix" 
              className="h-10 mr-2"
            />
          </div>

          {/* Auth Title */}
          <h2 className="text-2xl font-bold text-gray-900 mb-1">
            {isRegister ? "Create an account" : "Welcome back"}
          </h2>
          <p className="text-gray-500 mb-8">
            {isRegister ? "Sign up to start using Rutomatrix" : "Sign in to continue to your AI dashboard"}
          </p>

          {/* Login Form */}
          {!isRegister && (
            <form onSubmit={loginForm.handleSubmit(onLoginSubmit)} className="space-y-6" autoComplete="off">
              {loginMutation.isError && (
                <div className="bg-red-50 text-red-500 text-sm p-3 rounded-lg border border-red-200">
                  Invalid username or password
                </div>
              )}
              
              <div className="space-y-2">
                <Label htmlFor="login-username">Username</Label>
                <Input
                  id="login-username"
                  placeholder="you@example.com"
                  autoComplete="off"
                  {...loginForm.register("username")}
                  className={loginForm.formState.errors.username ? "border-red-500" : ""}
                />
                {loginForm.formState.errors.username && (
                  <p className="text-red-500 text-xs">{loginForm.formState.errors.username.message}</p>
                )}
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="login-password">Password</Label>
                <div className="relative">
                  <Input
                    id="login-password"
                    type={showPassword ? "text" : "password"}
                    placeholder="••••••••"
                    autoComplete="new-password"
                    {...loginForm.register("password")}
                    className={loginForm.formState.errors.password ? "border-red-500 pr-10" : "pr-10"}
                  />
                  <button
                    type="button"
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </div>
                {loginForm.formState.errors.password && (
                  <p className="text-red-500 text-xs">{loginForm.formState.errors.password.message}</p>
                )}
              </div>
              
              <div className="text-right">
                <a href="#" className="text-primary text-sm hover:underline">
                  Forgot password?
                </a>
              </div>
              
              <Button 
                type="submit" 
                className="w-full" 
                disabled={loginMutation.isPending}
              >
                {loginMutation.isPending ? (
                  <div className="flex items-center justify-center gap-2">
                    <Loader2 className="h-4 w-4 animate-spin" />
                    <span>Signing in...</span>
                  </div>
                ) : (
                  "Sign In"
                )}
              </Button>
            </form>
          )}

          {/* Register Form */}
          {isRegister && (
            <form onSubmit={registerForm.handleSubmit(onRegisterSubmit)} className="space-y-6" autoComplete="off">
              {registerMutation.isError && (
                <div className="bg-red-50 text-red-500 text-sm p-3 rounded-lg border border-red-200">
                  Registration failed. Username may already exist.
                </div>
              )}
              
              <div className="space-y-2">
                <Label htmlFor="reg-fullname">Full Name</Label>
                <Input
                  id="reg-fullname"
                  placeholder="John Doe"
                  autoComplete="off"
                  {...registerForm.register("fullName")}
                  className={registerForm.formState.errors.fullName ? "border-red-500" : ""}
                />
                {registerForm.formState.errors.fullName && (
                  <p className="text-red-500 text-xs">{registerForm.formState.errors.fullName.message}</p>
                )}
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="reg-email">Email</Label>
                <Input
                  id="reg-email"
                  type="email"
                  placeholder="you@example.com"
                  autoComplete="off"
                  {...registerForm.register("email")}
                  className={registerForm.formState.errors.email ? "border-red-500" : ""}
                />
                {registerForm.formState.errors.email && (
                  <p className="text-red-500 text-xs">{registerForm.formState.errors.email.message}</p>
                )}
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="reg-username">Username</Label>
                <Input
                  id="reg-username"
                  placeholder="johnsmith"
                  autoComplete="off"
                  {...registerForm.register("username")}
                  className={registerForm.formState.errors.username ? "border-red-500" : ""}
                />
                {registerForm.formState.errors.username && (
                  <p className="text-red-500 text-xs">{registerForm.formState.errors.username.message}</p>
                )}
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="reg-password">Password</Label>
                <div className="relative">
                  <Input
                    id="reg-password"
                    type={showPassword ? "text" : "password"}
                    placeholder="••••••••"
                    autoComplete="new-password"
                    {...registerForm.register("password", {
                      onChange: (e) => checkPasswordStrength(e.target.value)
                    })}
                    className={registerForm.formState.errors.password ? "border-red-500 pr-10" : "pr-10"}
                  />
                  <button
                    type="button"
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </div>
                
                {/* Password Strength Indicator */}
                <div className="w-full h-1 bg-gray-200 rounded-full overflow-hidden">
                  <div 
                    className={`h-full transition-all duration-300 ${
                      passwordStrength.score === 0 ? 'w-0 bg-transparent' :
                      passwordStrength.score < 3 ? 'w-1/3 bg-red-500' :
                      passwordStrength.score < 5 ? 'w-2/3 bg-yellow-500' :
                      'w-full bg-green-500'
                    }`}
                  ></div>
                </div>
                
                {/* Password Requirements */}
                <div className="text-xs space-y-1 mt-2">
                  <div className={`flex items-center ${passwordStrength.lengthValid ? 'text-green-500' : 'text-gray-400'}`}>
                    <div className="w-3 h-3 mr-2 rounded-full border border-current flex items-center justify-center">
                      {passwordStrength.lengthValid && <div className="w-1.5 h-1.5 rounded-full bg-current"></div>}
                    </div>
                    <span>At least 8 characters</span>
                  </div>
                  <div className={`flex items-center ${passwordStrength.hasUppercase ? 'text-green-500' : 'text-gray-400'}`}>
                    <div className="w-3 h-3 mr-2 rounded-full border border-current flex items-center justify-center">
                      {passwordStrength.hasUppercase && <div className="w-1.5 h-1.5 rounded-full bg-current"></div>}
                    </div>
                    <span>At least 1 uppercase letter</span>
                  </div>
                  <div className={`flex items-center ${passwordStrength.hasLowercase ? 'text-green-500' : 'text-gray-400'}`}>
                    <div className="w-3 h-3 mr-2 rounded-full border border-current flex items-center justify-center">
                      {passwordStrength.hasLowercase && <div className="w-1.5 h-1.5 rounded-full bg-current"></div>}
                    </div>
                    <span>At least 1 lowercase letter</span>
                  </div>
                  <div className={`flex items-center ${passwordStrength.hasNumber ? 'text-green-500' : 'text-gray-400'}`}>
                    <div className="w-3 h-3 mr-2 rounded-full border border-current flex items-center justify-center">
                      {passwordStrength.hasNumber && <div className="w-1.5 h-1.5 rounded-full bg-current"></div>}
                    </div>
                    <span>At least 1 number</span>
                  </div>
                  <div className={`flex items-center ${passwordStrength.hasSpecial ? 'text-green-500' : 'text-gray-400'}`}>
                    <div className="w-3 h-3 mr-2 rounded-full border border-current flex items-center justify-center">
                      {passwordStrength.hasSpecial && <div className="w-1.5 h-1.5 rounded-full bg-current"></div>}
                    </div>
                    <span>At least 1 special character</span>
                  </div>
                </div>
                
                {registerForm.formState.errors.password && (
                  <p className="text-red-500 text-xs mt-2">{registerForm.formState.errors.password.message}</p>
                )}
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="reg-confirm-password">Confirm Password</Label>
                <div className="relative">
                  <Input
                    id="reg-confirm-password"
                    type={showPassword ? "text" : "password"}
                    placeholder="••••••••"
                    autoComplete="new-password"
                    {...registerForm.register("confirmPassword")}
                    className={registerForm.formState.errors.confirmPassword ? "border-red-500 pr-10" : "pr-10"}
                  />
                  <button
                    type="button"
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </div>
                {registerForm.formState.errors.confirmPassword && (
                  <p className="text-red-500 text-xs">{registerForm.formState.errors.confirmPassword.message}</p>
                )}
              </div>
              
              <Button 
                type="submit" 
                className="w-full" 
                disabled={registerMutation.isPending}
              >
                {registerMutation.isPending ? (
                  <div className="flex items-center justify-center gap-2">
                    <Loader2 className="h-4 w-4 animate-spin" />
                    <span>Creating account...</span>
                  </div>
                ) : (
                  "Create Account"
                )}
              </Button>
            </form>
          )}

          {/* Social Login Options */}
          <div className="mt-6 mb-6 relative flex items-center justify-center">
            <div className="absolute w-full border-t border-primary/30"></div>
            <span className="relative bg-white px-3 text-sm text-secondary">or continue with</span>
          </div>

          <div className="flex justify-center gap-4 mb-6">
            {/* Google */}
            <button className="w-12 h-12 rounded-full bg-secondary/10 flex items-center justify-center text-secondary hover:bg-secondary/20 transition-colors">
              <svg className="w-5 h-5" viewBox="0 0 24 24">
                <path d="M12.545,10.239v3.821h5.445c-0.712,2.315-2.647,3.972-5.445,3.972c-3.332,0-6.033-2.701-6.033-6.032s2.701-6.032,6.033-6.032c1.498,0,2.866,0.549,3.921,1.453l2.814-2.814C17.503,2.988,15.139,2,12.545,2C7.021,2,2.543,6.477,2.543,12s4.478,10,10.002,10c8.396,0,10.249-7.85,9.426-11.748L12.545,10.239z" fill="currentColor"/>
              </svg>
            </button>
            
            {/* GitHub */}
            <button className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary hover:bg-primary/20 transition-colors">
              <svg className="w-5 h-5" viewBox="0 0 24 24">
                <path d="M12 2C6.477 2 2 6.477 2 12c0 4.42 2.865 8.167 6.839 9.489.5.092.682-.217.682-.482 0-.237-.008-.866-.013-1.7-2.782.605-3.369-1.343-3.369-1.343-.454-1.155-1.11-1.462-1.11-1.462-.908-.62.069-.608.069-.608 1.003.07 1.531 1.03 1.531 1.03.892 1.529 2.341 1.087 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.11-4.555-4.943 0-1.091.39-1.984 1.029-2.683-.103-.253-.446-1.272.098-2.65 0 0 .84-.269 2.75 1.025A9.564 9.564 0 0112 6.844c.85.004 1.705.115 2.504.337 1.909-1.294 2.747-1.025 2.747-1.025.546 1.378.202 2.397.1 2.65.64.699 1.028 1.592 1.028 2.683 0 3.841-2.337 4.687-4.565 4.935.359.309.678.92.678 1.855 0 1.338-.012 2.419-.012 2.747 0 .268.18.58.688.482A10.019 10.019 0 0022 12c0-5.523-4.477-10-10-10z" fill="currentColor"/>
              </svg>
            </button>
            
            {/* Microsoft */}
            <button className="w-12 h-12 rounded-full bg-secondary/10 flex items-center justify-center text-secondary hover:bg-secondary/20 transition-colors">
              <svg className="w-5 h-5" viewBox="0 0 24 24">
                <path d="M11.4 24H0V12.6h11.4V24zM24 24H12.6V12.6H24V24zM11.4 11.4H0V0h11.4v11.4zM24 11.4H12.6V0H24v11.4z" fill="currentColor"/>
              </svg>
            </button>
          </div>

          {/* Toggle between Login and Register */}
          <div className="text-center text-gray-500">
            {isRegister ? (
              <>Already have an account? <a href="#" onClick={toggleAuthMode} className="text-primary font-medium hover:underline">Sign in</a></>
            ) : (
              <>Don't have an account? <a href="#" onClick={toggleAuthMode} className="text-primary font-medium hover:underline">Sign up</a></>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}