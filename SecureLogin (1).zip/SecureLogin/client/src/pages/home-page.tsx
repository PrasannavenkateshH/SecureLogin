import { useState, useEffect } from "react";
import { useAuth } from "../hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Loader2 } from "lucide-react";

export default function HomePage() {
  const { user, logoutMutation } = useAuth();
  
  // Redirect to external dashboard
  useEffect(() => {
    window.location.href = "https://rutomatrix.com/dashboard";
  }, []);
  
  const [messages, setMessages] = useState<{role: string, content: string}[]>([
    {
      role: "assistant",
      content: "Hello! I'm RutoAI, your AI language assistant. How can I help you today?"
    }
  ]);
  const [inputValue, setInputValue] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    // Send message on Enter (not holding shift)
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const handleTextareaChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setInputValue(e.target.value);
    
    // Adjust textarea height
    const textarea = e.target;
    textarea.style.height = "auto";
    textarea.style.height = `${textarea.scrollHeight}px`;
  };

  const sendMessage = () => {
    if (!inputValue.trim() || isLoading) return;

    // Add user message
    const userMessage = inputValue.trim();
    const newMessages = [...messages, { role: "user", content: userMessage }];
    setMessages(newMessages);
    setInputValue("");
    
    // Simulate AI response
    setIsLoading(true);
    setTimeout(() => {
      // Generate AI response based on user message
      generateAIResponse(userMessage);
    }, 1000);
  };

  const generateAIResponse = (userMessage: string) => {
    // Simple response generation for demo purposes
    let responseText = "I'm sorry, I don't have enough information to respond to that.";
    
    if (userMessage.toLowerCase().includes("hello") || userMessage.toLowerCase().includes("hi")) {
      responseText = "Hello there! How can I assist you today?";
    } else if (userMessage.toLowerCase().includes("help")) {
      responseText = "I'm here to help! You can ask me about generating text, answering questions, or assisting with creative writing.";
    } else if (userMessage.toLowerCase().includes("weather")) {
      responseText = "I don't have access to real-time weather data, but I'd be happy to help you with language tasks!";
    } else if (userMessage.toLowerCase().includes("name")) {
      responseText = "My name is RutoAI. I'm a language model designed to assist you.";
    } else if (userMessage.length < 10) {
      responseText = "Could you provide more details so I can help you better?";
    } else {
      responseText = "That's an interesting point. I'd like to learn more about what you're working on so I can provide more tailored assistance.";
    }
    
    // Add AI response to messages
    setMessages(prev => [...prev, { role: "assistant", content: responseText }]);
    setIsLoading(false);
  };

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  return (
    <div className="flex flex-col h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 py-4 px-6 flex items-center justify-between">
        <div className="flex items-center">
          <div className="text-primary mr-2">
            <svg className="w-7 h-7" viewBox="0 0 20 20" fill="currentColor">
              <path d="M10 3.5a1.5 1.5 0 013 0V4a1 1 0 001 1h3a1 1 0 011 1v3a1 1 0 01-1 1h-.5a1.5 1.5 0 000 3h.5a1 1 0 011 1v3a1 1 0 01-1 1h-3a1 1 0 01-1-1v-.5a1.5 1.5 0 00-3 0v.5a1 1 0 01-1 1H6a1 1 0 01-1-1v-3a1 1 0 00-1-1h-.5a1.5 1.5 0 010-3H4a1 1 0 001-1V6a1 1 0 011-1h3a1 1 0 001-1v-.5z" />
            </svg>
          </div>
          <h1 className="text-xl font-bold">RutoAI</h1>
        </div>
        
        <div className="flex items-center">
          <span className="mr-4 text-gray-600">Welcome, {user?.username}</span>
          <Button variant="outline" onClick={handleLogout} disabled={logoutMutation.isPending}>
            {logoutMutation.isPending ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              "Sign Out"
            )}
          </Button>
        </div>
      </header>
      
      {/* Main Chat Area */}
      <div className="flex-1 overflow-hidden flex flex-col p-4 max-w-4xl mx-auto w-full">
        {/* Messages */}
        <div className="flex-1 overflow-y-auto mb-4 space-y-4 p-4">
          {messages.map((message, index) => (
            <div 
              key={index} 
              className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}
            >
              <div 
                className={`rounded-2xl px-4 py-3 max-w-[80%] ${
                  message.role === "user" 
                    ? "bg-primary text-white rounded-tr-none" 
                    : "bg-white border border-gray-200 rounded-tl-none"
                }`}
              >
                {message.content}
              </div>
            </div>
          ))}
          
          {/* Loading Indicator */}
          {isLoading && (
            <div className="flex justify-start">
              <div className="bg-white border border-gray-200 rounded-2xl rounded-tl-none px-4 py-3">
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 rounded-full bg-gray-300 animate-bounce" style={{ animationDelay: "0ms" }}></div>
                  <div className="w-2 h-2 rounded-full bg-gray-300 animate-bounce" style={{ animationDelay: "150ms" }}></div>
                  <div className="w-2 h-2 rounded-full bg-gray-300 animate-bounce" style={{ animationDelay: "300ms" }}></div>
                </div>
              </div>
            </div>
          )}
        </div>
        
        {/* Input Area */}
        <div className="relative bg-white border border-gray-200 rounded-xl">
          <Textarea
            value={inputValue}
            onChange={handleTextareaChange}
            onKeyDown={handleKeyDown}
            placeholder="Type your message..."
            className="min-h-[60px] max-h-[200px] resize-none border-0 focus-visible:ring-0 focus-visible:ring-offset-0 p-4 pr-20"
          />
          <Button 
            onClick={sendMessage} 
            className="absolute bottom-3 right-3"
            size="sm"
            disabled={!inputValue.trim() || isLoading}
          >
            Send
          </Button>
        </div>
      </div>
    </div>
  );
}