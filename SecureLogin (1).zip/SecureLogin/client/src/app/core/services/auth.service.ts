import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of, throwError } from 'rxjs';
import { catchError, delay, map, tap } from 'rxjs/operators';
import { LoginCredentials, LoginResponse, User } from '../models/user.model';
import { environment } from '../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private readonly TOKEN_KEY = 'auth_token';
  private readonly USER_KEY = 'auth_user';
  private apiUrl = environment.apiUrl;

  constructor(private http: HttpClient) { }

  login(credentials: LoginCredentials): Observable<User> {
    return this.http.post<LoginResponse>(`${this.apiUrl}/login`, credentials)
      .pipe(
        map(response => {
          // Store token and user in localStorage
          this.setToken(response.access_token);
          this.setUser(response.user);
          return response.user;
        }),
        catchError(error => {
          return throwError(() => new Error(error.error?.message || 'Login failed. Please check your credentials.'));
        })
      );
  }

  // Simulated login for demo purposes if the backend is not yet ready
  mockLogin(credentials: LoginCredentials): Observable<User> {
    if (credentials.email === 'demo@example.com' && credentials.password === 'password') {
      const mockUser: User = {
        id: 1,
        email: credentials.email,
        name: 'Demo User',
        token: 'mock-jwt-token'
      };
      
      // Simulate network delay
      return of(mockUser).pipe(
        delay(1500),
        tap(user => {
          this.setToken(user.token!);
          this.setUser(user);
        })
      );
    } else {
      return throwError(() => new Error('Invalid email or password'));
    }
  }

  logout(): void {
    localStorage.removeItem(this.TOKEN_KEY);
    localStorage.removeItem(this.USER_KEY);
  }

  getToken(): string | null {
    return localStorage.getItem(this.TOKEN_KEY);
  }

  isLoggedIn(): boolean {
    return !!this.getToken();
  }

  getCurrentUser(): User | null {
    const userStr = localStorage.getItem(this.USER_KEY);
    return userStr ? JSON.parse(userStr) : null;
  }

  private setToken(token: string): void {
    localStorage.setItem(this.TOKEN_KEY, token);
  }

  private setUser(user: User): void {
    localStorage.setItem(this.USER_KEY, JSON.stringify(user));
  }

  // Social login methods (mocked for now)
  loginWithGoogle(): Observable<User> {
    return this.simulateSocialLogin('google');
  }

  loginWithGithub(): Observable<User> {
    return this.simulateSocialLogin('github');
  }

  loginWithMicrosoft(): Observable<User> {
    return this.simulateSocialLogin('microsoft');
  }

  private simulateSocialLogin(provider: string): Observable<User> {
    const mockUser: User = {
      id: 2,
      email: `user@${provider}.com`,
      name: `${provider.charAt(0).toUpperCase() + provider.slice(1)} User`,
      token: `mock-${provider}-token`
    };
    
    return of(mockUser).pipe(
      delay(1500),
      tap(user => {
        this.setToken(user.token!);
        this.setUser(user);
      })
    );
  }
}
