import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';

@Component({
  selector: 'app-social-login',
  templateUrl: './social-login.component.html',
  styleUrls: ['./social-login.component.scss']
})
export class SocialLoginComponent {
  isLoading = false;

  constructor(
    private authService: AuthService,
    private router: Router
  ) { }

  loginWithGoogle(): void {
    this.handleSocialLogin(() => this.authService.loginWithGoogle());
  }

  loginWithGithub(): void {
    this.handleSocialLogin(() => this.authService.loginWithGithub());
  }

  loginWithMicrosoft(): void {
    this.handleSocialLogin(() => this.authService.loginWithMicrosoft());
  }

  private handleSocialLogin(loginFn: () => any): void {
    this.isLoading = true;
    
    loginFn().subscribe({
      next: () => {
        this.isLoading = false;
        this.router.navigate(['/dashboard']);
      },
      error: (error: any) => {
        this.isLoading = false;
        console.error('Social login error:', error);
        // Could display an error message here
      }
    });
  }
}
