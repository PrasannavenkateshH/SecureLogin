import { Component, forwardRef, Input } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';

@Component({
  selector: 'app-password-field',
  templateUrl: './password-field.component.html',
  styleUrls: ['./password-field.component.scss'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => PasswordFieldComponent),
      multi: true
    }
  ]
})
export class PasswordFieldComponent implements ControlValueAccessor {
  @Input() showErrors = false;
  
  password = '';
  showPassword = false;
  disabled = false;

  // Function to call when the input changes
  onChange: any = () => {};
  // Function to call when the input is touched
  onTouched: any = () => {};

  togglePasswordVisibility(): void {
    this.showPassword = !this.showPassword;
  }

  // ControlValueAccessor methods
  writeValue(value: string): void {
    this.password = value || '';
  }

  registerOnChange(fn: any): void {
    this.onChange = fn;
  }

  registerOnTouched(fn: any): void {
    this.onTouched = fn;
  }

  setDisabledState(isDisabled: boolean): void {
    this.disabled = isDisabled;
  }

  // Called when input value changes
  onInputChange(event: Event): void {
    const value = (event.target as HTMLInputElement).value;
    this.password = value;
    this.onChange(value);
  }

  // Called on blur
  onBlur(): void {
    this.onTouched();
  }
}
