import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
    this.generateAIParticles();
  }

  generateAIParticles(): void {
    // This will be handled in the template with ngFor
    // The actual particle generation will happen in component initialization
  }

  // Generate an array of particles with random properties
  get particles(): any[] {
    const particles = [];
    for (let i = 0; i < 20; i++) {
      particles.push({
        size: Math.random() * 10 + 5,
        posX: Math.random() * 100,
        posY: Math.random() * 100,
        opacity: Math.random() * 0.2 + 0.05,
        blur: Math.random() * 5 + 2,
        duration: Math.random() * 10 + 10
      });
    }
    return particles;
  }
}
