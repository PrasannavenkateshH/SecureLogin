document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const chatHistory = document.getElementById('chatHistory');
    const messageInput = document.getElementById('messageInput');
    const sendMessageBtn = document.getElementById('sendMessageBtn');
    const logoutBtn = document.getElementById('logoutBtn');
    const promptSuggestions = document.querySelectorAll('.suggestion-btn');
    const modelSelect = document.getElementById('modelSelect');
    
    // Model parameters
    const temperatureSlider = document.getElementById('temperature');
    const maxTokensSlider = document.getElementById('maxTokens');
    const topPSlider = document.getElementById('topP');
    const tempValue = document.getElementById('tempValue');
    const tokenValue = document.getElementById('tokenValue');
    const topPValue = document.getElementById('topPValue');

    // Check authentication
    const token = localStorage.getItem('token');
    if (!token) {
        window.location.href = 'login.html';
        return;
    }

    // Load user data
    const user = JSON.parse(localStorage.getItem('user'));
    if (user) {
        document.querySelector('.user-name').textContent = user.name || 'User';
        document.querySelector('.user-email').textContent = user.email || 'user@example.com';
        
        // Update avatar if available
        if (user.email) {
            const avatar = document.querySelector('.user-profile img');
            avatar.src = `https://ui-avatars.com/api/?name=${encodeURIComponent(user.name || 'User')}&background=6366f1&color=fff`;
        }
    }

    // Initialize chat
    loadChatHistory();

    // Event Listeners
    messageInput.addEventListener('input', adjustTextareaHeight);
    messageInput.addEventListener('keydown', handleKeyDown);
    sendMessageBtn.addEventListener('click', sendMessage);
    logoutBtn.addEventListener('click', logout);
    
    // Add click events to prompt suggestions
    promptSuggestions.forEach(btn => {
        btn.addEventListener('click', function() {
            messageInput.value = this.textContent;
            messageInput.focus();
            adjustTextareaHeight();
        });
    });

    // Model parameter sliders
    temperatureSlider.addEventListener('input', function() {
        tempValue.textContent = this.value;
    });
    
    maxTokensSlider.addEventListener('input', function() {
        tokenValue.textContent = this.value;
    });
    
    topPSlider.addEventListener('input', function() {
        topPValue.textContent = this.value;
    });

    // Functions
    function adjustTextareaHeight() {
        messageInput.style.height = 'auto';
        messageInput.style.height = `${Math.min(messageInput.scrollHeight, 200)}px`;
    }

    function handleKeyDown(e) {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    }

    function sendMessage() {
        const message = messageInput.value.trim();
        if (!message) return;

        // Add user message to chat
        addMessageToChat('user', message);
        messageInput.value = '';
        adjustTextareaHeight();
        
        // Show typing indicator
        showTypingIndicator();
        
        // Disable send button during request
        sendMessageBtn.disabled = true;

        // Prepare request data
        const requestData = {
            model: modelSelect.value,
            messages: getChatHistory(),
            temperature: parseFloat(temperatureSlider.value),
            max_tokens: parseInt(maxTokensSlider.value),
            top_p: parseFloat(topPSlider.value)
        };

        // Simulate API call (replace with actual fetch to your backend)
        setTimeout(() => {
            // Remove typing indicator
            removeTypingIndicator();
            
            // Simulate AI response
            const aiResponse = generateAIResponse(message);
            addMessageToChat('assistant', aiResponse);
            
            // Re-enable send button
            sendMessageBtn.disabled = false;
        }, 1500);
    }

    function addMessageToChat(role, content) {
        const messageDiv = document.createElement('div');
        messageDiv.classList.add('message', `${role}-message`);
        
        messageDiv.innerHTML = `
            <div class="message-content">${content}</div>
            <div class="message-meta">
                <span>${role === 'user' ? 'You' : 'NeuraLingua'}</span>
                <span>${new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
            </div>
        `;
        
        chatHistory.appendChild(messageDiv);
        chatHistory.scrollTop = chatHistory.scrollHeight;
        
        // Save to chat history
        saveChatMessage(role, content);
    }

    function showTypingIndicator() {
        const typingDiv = document.createElement('div');
        typingDiv.classList.add('typing-indicator');
        typingDiv.id = 'typingIndicator';
        
        typingDiv.innerHTML = `
            <div class="typing-dot"></div>
            <div class="typing-dot"></div>
            <div class="typing-dot"></div>
        `;
        
        chatHistory.appendChild(typingDiv);
        chatHistory.scrollTop = chatHistory.scrollHeight;
    }

    function removeTypingIndicator() {
        const typingIndicator = document.getElementById('typingIndicator');
        if (typingIndicator) {
            typingIndicator.remove();
        }
    }

    function generateAIResponse(userMessage) {
        // This is a simplified response generator
        // In a real app, this would come from your LLM API
        const responses = [
            "I've analyzed your request and here's what I found...",
            "That's an interesting question. Based on my knowledge...",
            "Here's the information you requested:",
            "I can help with that. Here's what you need to know..."
        ];
        
        const randomResponse = responses[Math.floor(Math.random() * responses.length)];
        return `${randomResponse}\n\nThis is a simulated response. In a real application, this would be generated by the ${modelSelect.value} model.`;
    }

    function saveChatMessage(role, content) {
        let chatHistory = JSON.parse(localStorage.getItem('chatHistory') || '[]');
        chatHistory.push({
            role,
            content,
            timestamp: new Date().toISOString()
        });
        localStorage.setItem('chatHistory', JSON.stringify(chatHistory));
    }

    function loadChatHistory() {
        const chatHistory = JSON.parse(localStorage.getItem('chatHistory') || '[]');
        chatHistory.forEach(msg => {
            addMessageToChat(msg.role, msg.content);
        });
    }

    function getChatHistory() {
        // Format chat history for API request
        const history = JSON.parse(localStorage.getItem('chatHistory') || '[]');
        return history.map(msg => ({
            role: msg.role,
            content: msg.content
        }));
    }

    function logout() {
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        localStorage.removeItem('chatHistory');
        window.location.href = 'login.html';
    }
});