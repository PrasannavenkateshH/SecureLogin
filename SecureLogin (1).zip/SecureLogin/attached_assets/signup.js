document.addEventListener('DOMContentLoaded', function() {
    // Generate AI particles
    const backgroundPattern = document.getElementById('backgroundPattern');
    for (let i = 0; i < 20; i++) {
        const particle = document.createElement('div');
        particle.classList.add('ai-particle');
        
        const size = Math.random() * 10 + 5;
        const posX = Math.random() * 100;
        const posY = Math.random() * 100;
        const opacity = Math.random() * 0.2 + 0.05;
        const blur = Math.random() * 5 + 2;
        const duration = Math.random() * 10 + 10;
        
        particle.style.width = `${size}px`;
        particle.style.height = `${size}px`;
        particle.style.left = `${posX}%`;
        particle.style.top = `${posY}%`;
        particle.style.opacity = opacity;
        particle.style.filter = `blur(${blur}px)`;
        particle.style.animationDuration = `${duration}s`;
        
        backgroundPattern.appendChild(particle);
    }

    // Password toggle
    const togglePassword = document.getElementById('togglePassword');
    const toggleConfirmPassword = document.getElementById('toggleConfirmPassword');
    const password = document.getElementById('password');
    const confirmPassword = document.getElementById('confirmPassword');
    
    togglePassword.addEventListener('click', function() {
        const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
        password.setAttribute('type', type);
        this.classList.toggle('fa-eye');
        this.classList.toggle('fa-eye-slash');
    });
    
    toggleConfirmPassword.addEventListener('click', function() {
        const type = confirmPassword.getAttribute('type') === 'password' ? 'text' : 'password';
        confirmPassword.setAttribute('type', type);
        this.classList.toggle('fa-eye');
        this.classList.toggle('fa-eye-slash');
    });

    // Password strength checker
    password.addEventListener('input', function() {
        const value = this.value;
        const strengthBar = document.getElementById('passwordStrength');
        
        // Reset requirements
        document.querySelectorAll('.requirement').forEach(req => {
            req.classList.remove('valid');
            req.querySelector('i').className = 'fas fa-circle';
        });
        
        // Check requirements
        let strength = 0;
        const requirements = {
            length: value.length >= 8,
            upper: /[A-Z]/.test(value),
            lower: /[a-z]/.test(value),
            number: /[0-9]/.test(value),
            special: /[^A-Za-z0-9]/.test(value)
        };
        
        // Update UI for each requirement
        if (requirements.length) {
            document.getElementById('lengthReq').classList.add('valid');
            document.getElementById('lengthReq').querySelector('i').className = 'fas fa-check-circle';
            strength += 20;
        }
        if (requirements.upper) {
            document.getElementById('upperReq').classList.add('valid');
            document.getElementById('upperReq').querySelector('i').className = 'fas fa-check-circle';
            strength += 20;
        }
        if (requirements.lower) {
            document.getElementById('lowerReq').classList.add('valid');
            document.getElementById('lowerReq').querySelector('i').className = 'fas fa-check-circle';
            strength += 20;
        }
        if (requirements.number) {
            document.getElementById('numberReq').classList.add('valid');
            document.getElementById('numberReq').querySelector('i').className = 'fas fa-check-circle';
            strength += 20;
        }
        if (requirements.special) {
            document.getElementById('specialReq').classList.add('valid');
            document.getElementById('specialReq').querySelector('i').className = 'fas fa-check-circle';
            strength += 20;
        }
        
        // Update strength bar
        strengthBar.style.width = `${strength}%`;
        
        // Change color based on strength
        if (strength < 40) {
            strengthBar.style.backgroundColor = 'var(--danger)';
        } else if (strength < 80) {
            strengthBar.style.backgroundColor = 'orange';
        } else {
            strengthBar.style.backgroundColor = 'var(--success)';
        }
    });

    // Form submission
    document.getElementById('signupForm').addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const name = document.getElementById('name').value;
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
        const confirmPassword = document.getElementById('confirmPassword').value;
        const errorMessage = document.getElementById('errorMessage');
        const successMessage = document.getElementById('successMessage');
        const signupBtn = document.getElementById('signupBtn');
        const signupText = document.getElementById('signupText');
        
        // Hide messages
        errorMessage.style.display = 'none';
        successMessage.style.display = 'none';
        
        // Client-side validation
        if (password !== confirmPassword) {
            errorMessage.textContent = 'Passwords do not match';
            errorMessage.style.display = 'block';
            return;
        }
        
        // Check password strength (at least 4 requirements met)
        const validRequirements = document.querySelectorAll('.requirement.valid').length;
        if (validRequirements < 4) {
            errorMessage.textContent = 'Password does not meet requirements';
            errorMessage.style.display = 'block';
            return;
        }
        
        // Show loading state
        signupBtn.disabled = true;
        signupText.innerHTML = '<div class="loading"></div> Creating account...';
        
        try {
            const response = await fetch('http://localhost:8000/api/signup', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ name, email, password }),
            });
            
            const data = await response.json();
            
            if (response.ok) {
                successMessage.textContent = 'Account created successfully! Redirecting to login...';
                successMessage.style.display = 'block';
                
                // Redirect to login after 2 seconds
                setTimeout(() => {
                    window.location.href = 'login.html';
                }, 2000);
            } else {
                errorMessage.textContent = data.detail || 'Registration failed. Please try again.';
                errorMessage.style.display = 'block';
            }
        } catch (error) {
            errorMessage.textContent = 'Network error. Please try again.';
            errorMessage.style.display = 'block';
            console.error('Error:', error);
        } finally {
            // Reset button state
            signupBtn.disabled = false;
            signupText.textContent = 'Create Account';
        }
    });
});