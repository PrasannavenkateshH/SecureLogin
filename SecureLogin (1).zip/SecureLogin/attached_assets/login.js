document.addEventListener('DOMContentLoaded', function() {
    // Generate AI particles
    const backgroundPattern = document.getElementById('backgroundPattern');
    for (let i = 0; i < 20; i++) {
        const particle = document.createElement('div');
        particle.classList.add('ai-particle');
        
        const size = Math.random() * 10 + 5;
        const posX = Math.random() * 100;
        const posY = Math.random() * 100;
        const opacity = Math.random() * 0.2 + 0.05;
        const blur = Math.random() * 5 + 2;
        const duration = Math.random() * 10 + 10;
        
        particle.style.width = `${size}px`;
        particle.style.height = `${size}px`;
        particle.style.left = `${posX}%`;
        particle.style.top = `${posY}%`;
        particle.style.opacity = opacity;
        particle.style.filter = `blur(${blur}px)`;
        particle.style.animationDuration = `${duration}s`;
        
        backgroundPattern.appendChild(particle);
    }

    // Password toggle
    const togglePassword = document.getElementById('togglePassword');
    const password = document.getElementById('password');
    
    togglePassword.addEventListener('click', function() {
        const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
        password.setAttribute('type', type);
        this.classList.toggle('fa-eye');
        this.classList.toggle('fa-eye-slash');
    });

    // Form submission
    document.getElementById('loginForm').addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
        const errorMessage = document.getElementById('errorMessage');
        const loginBtn = document.getElementById('loginBtn');
        const loginText = document.getElementById('loginText');
        
        // Show loading state
        loginBtn.disabled = true;
        loginText.innerHTML = '<div class="loading"></div> Signing in...';
        
        try {
            const response = await fetch('http://localhost:8000/api/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ email, password }),
            });
            
            const data = await response.json();
            
            if (response.ok) {
                // Save the token and redirect to dashboard
                localStorage.setItem('token', data.access_token);
                localStorage.setItem('user', JSON.stringify(data.user));
                window.location.href = 'dashboard.html';
            } else {
                errorMessage.textContent = data.detail || 'Login failed. Please check your credentials.';
                errorMessage.style.display = 'block';
            }
        } catch (error) {
            errorMessage.textContent = 'Network error. Please try again.';
            errorMessage.style.display = 'block';
            console.error('Error:', error);
        } finally {
            // Reset button state
            loginBtn.disabled = false;
            loginText.textContent = 'Sign In';
        }
    });
});